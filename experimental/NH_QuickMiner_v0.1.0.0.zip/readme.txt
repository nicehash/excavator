
Instructions:
1. Start NiceHashQuickMiner.exe.
2. Modify generated nhqm.conf by putting in your BTC address and your selected worker name.
3. Set autostart with Windows.
4. Enjoy carefree mining! 

serviceLocation 0 = eu
serviceLocation 1 = usa
Change serviceLocation, BTC, workerName, launchCommandLine, leave everything else as it is.

Use commands.json to put in OC settings for your cards.
Suggested to use in combination with octuner! It is very easy&fast to set OC clocks.

Updating from previous version? Make sure to full uninstall it first - 
remove Windows autostart in old version before you enable autostart in new one.