
Instructions:
1. Start NiceHashQuickMiner.exe.
2. Modify generated nhqm.conf by putting in your BTC address and your selected worker name.
3. Set autostart with Windows.
4. Use OCTune to adjust overclocks and fan speeds (do not use Afterburner, it is not needed).
5. Enjoy carefree mining! 

serviceLocation 0 = eu
serviceLocation 1 = usa
Change serviceLocation, BTC, workerName, launchCommandLine.
consoleLogLevel, fileLogLevel (for NiceHashQuickMiner); use following numbers:
0-6 which means:
0: log everything (TRACE)
1: log debug (DEBUG)
2: standard (INFO)
3: warnings (WARNING)
4: errors (ERROR)
5: fatal (FATAL)
6: no logging (disabled)

Please, enable full file logging ("fileLogLevel":0) and submit 
log files when error is found.

Updating from previous version? Make sure to full uninstall it first - 
remove Windows autostart in old version before you enable autostart in new one.

From version 0.2.0.0, CPU Mining with integrated XMRig is possible on modern CPUs
with AVX2. CPU Mining can be activated from the tray menu (or via Rig Manager). 
You can provide extra launch parameters for XMRig (config nhqm.conf), for example:

	"CPUMinerELP":"--cpu-max-threads-hint 50 --print-time 15"

First parameter above tells CPU miner to use only 50% of resources, second one prints
speed to console every 15 seconds. Parameters for lowest CPU priority, donation level 0%
and other important parameters are already provided by the Excavator.