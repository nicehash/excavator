
Instructions:
1. Start NiceHashQuickMiner.exe.
2. Modify generated nhqm.conf by putting in your BTC address and your selected worker name.
3. Set autostart with Windows.
4. Use OCTune to adjust overclocks and fan speeds (do not use Afterburner, it is not needed).
5. Enjoy carefree mining! 

serviceLocation 0 = eu
serviceLocation 1 = usa
Change serviceLocation, BTC, workerName, launchCommandLine.
consoleLogLevel, fileLogLevel (for NiceHashQuickMiner); use following numbers:
0-6 which means:
0: log everything (TRACE)
1: log debug (DEBUG)
2: standard (INFO)
3: warnings (WARNING)
4: errors (ERROR)
5: fatal (FATAL)
6: no logging (disabled)

Please, enable full file logging ("fileLogLevel":0) and submit 
log files when error is found.

Updating from previous version? Make sure to full uninstall it first - 
remove Windows autostart in old version before you enable autostart in new one.