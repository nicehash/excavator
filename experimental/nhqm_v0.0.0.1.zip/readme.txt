
Instructions:
1. Modify commands.json - put in your BTC address and do other things (OC etc...)
2. Start NiceHashQuickMiner.exe.
3. Enable/disable autostart with Windows.
4. Enjoy carefree mining! 
